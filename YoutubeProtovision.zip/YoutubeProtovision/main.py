#========================= IMPORTS ==========================#

import os
import sys
from ftplib import FTP
import paramiko 

#========================= GLOBAL ===========================#

host = "HOSTNAME"
user = "USERNAME"
pw = "PASSWORD"
port = "PORT"
remote = 'REMOTE MAIN DIRECTORY'
os.chdir('YoutubeProtovision/')
f = open("playlists.txt", "r").read().split('\n')
base = [line.split(" ") for line in f ]

#========================== TOOLS ===========================#

def createRequest(name, link):
    startRequest = os.getenv("HOME") + "/Scripts/Youtube-dl/bin/youtube-dl -4 -i --extract-audio --audio-format mp3 --download-archive archives/"
    request = startRequest + name + ".txt -o mp3/" + name + "/%(title)s.%(ext)s --yes-playlist " + link
    return request

def sftp_exists(sftp, path):
    try:
        sftp.stat(path)
        return True
    except FileNotFoundError :
        return False

def printProgressDecimal(x,y):
    if int(100*(int(x)/int(y))) % progressEveryPercent ==0 and progressDict[str(int(100*(int(x)/int(y))))]=="":
        print(str(int((100*(int(x)/int(y))))) + ' %')
        progressDict[str(int(100*(int(x)/int(y))))]="1"

progressDict={}
progressEveryPercent=10
for i in range(0,101):
    if i%progressEveryPercent==0:
        progressDict[str(i)]=""

#===================== MUSIC DOWNLOAD =======================#

print('  ')
print(' -- LOOKING FOR NEW TRACKS -- ')
print('  ')

if len(sys.argv)==1:
    for p in base :
        os.system(createRequest(p[0], p[1]))
        print(' ')

else:
    for name in sys.argv[1:]:
        for p in base :
            if name==p[0]:
                os.system(createRequest(p[0], p[1]))
                print(' ')

#========================= RENAMING ===========================#

folders = os.listdir('mp3/')
for fold in folders:
    if (str(fold) != 'desktop.ini'):
        if len(os.listdir('mp3/' + fold)) != 0:
            for file in os.listdir('mp3/' + fold):
                src='mp3/' + fold+'/'+ file
                dst=src.replace(' ', '_')
                os.rename(src,dst)

#========================= OUTPUT ===========================#

print('  ')
if (len(sys.argv)) == 2:
    print(' -- ' + str(len(sys.argv) - 1) + ' DATABASE UPDATED -- ')
else:
    print(' -- ' + str(len(sys.argv) - 1) + ' DATABASES UPDATED -- ')
print('  ')

#======================= FTP CONNECTION =====================#
        
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(host, port, user, pw)
sftp = ssh.open_sftp()

print('  ')
print(" -- CONNECTED -- ")
print('  ')

#====================== FILES DETECTION =====================#

counter = 0
folders = os.listdir('mp3/')
numberFile = 0
for fold in folders:
    if (str(fold) != 'desktop.ini'):
        for file in os.listdir('mp3/' + fold):
            numberFile += 1

if numberFile == 0:
    print('NO FILE DETECTED')
    print(' ')
    sftp.close()
    ssh.close()
    print(' -- DISCONNECTED -- ')
    
else:
    if numberFile <2 :
        print(str(numberFile) + ' FILE DETECTED')
    else :
        print(str(numberFile) + ' FILES DETECTED')

#====================== FILES TRANSFERT =====================#
        
    for fold in folders:
        if (str(fold) != 'desktop.ini'):
            for file in os.listdir('mp3/' + fold):
                localPath = 'mp3/' + fold + '/' + file
                dPath = remote + 'mp3/' + fold
                remotePath = remote + 'mp3/' + fold + '/' + file
                if fold not in sftp.listdir(remote + 'mp3/'):
                     sftp.mkdir(dPath, 755)
                sftp.put(localPath, remotePath)
                os.remove(localPath)
                counter+=1
                print('PROGRESS : ' + str(counter) + ' / ' + str(numberFile))
            archiveLocalPath = 'archives/' + fold + '.txt'
            archiveRemotePath = remote + 'archives/' + fold + '.txt'
            if sftp_exists(sftp, archiveRemotePath):
                sftp.remove(archiveRemotePath)
            sftp.put(archiveLocalPath, archiveRemotePath)
            
#===================== FTP DECONNECTION ====================#

    sftp.close()
    ssh.close()
    print('  ')
    print(str(counter) + ' FILES UPLOADED')
    print('  ')
    print(' -- DISCONNECTED -- ')
    print('  ')
